<style>
.tit{
	font-size: 20px;
}
</style>
<div>
	<div class='tit'>歡迎 "<?php echo $nickname;?>" !</div>
</div>