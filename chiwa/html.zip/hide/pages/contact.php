<style>
#frbar{
    border-bottom: 1px solid #00000033;
	background-color: #f9f9f9;
}
#frbar > div{
    font-size: 20px;
    font-weight: bold;
    position: relative;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
}
#title{
    text-align: center;
}
.min{
	font-family: consolas, monospace, Microsoft JhengHei;
	max-width: 800px;
	margin: auto;
    padding: 16px 8px;
    min-height: calc(100vh - 207px);
}
</style>
<div id='frbar'><div>
	<div id='title'>線上瑜伽課程互動平台</div>
</div></div>
<div class='min'>
	<div>Contact</div>
	<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
	<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
	<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
	<br/><br/><br/><br/><br/>
</div>