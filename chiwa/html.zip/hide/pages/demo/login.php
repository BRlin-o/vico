<style>
#box{
    height: 80vh;
    display: flex;
    align-items: center;
    justify-content: center;
}
#box2{
    width: fit-content;
}
#box2 .a{
	font-size: 20px;
    line-height: 30px;	
}
#box2 input{
	font-size: 18px;
	margin-bottom: 16px;
}
</style>
<div id='box'>
	<div id='box2'>
		<div class='a'>帳號</div>
		<div><input/></div>
		<div class='a'>密碼</div>
		<div><input/></div>
		<div><div class='btn' style='right: 0;left: 0;margin: 8px auto;'>登入</div></div>
	</div>
</div>