<style>
#frPage > div {
    padding: 4px 0px;
}
.title0{
	font-size: 20px;
	font-weight: bold;
    padding: 0px 20px;
	padding-top: 14px;
}
.inbox{
    padding: 8px;
    box-shadow: 0 0 4px grey;
    border-radius: 6px;
    margin: 16px 20px;
    display: flex;
    justify-content: space-between;
}
.inbox .title{
	font-size: 18px;
	font-weight: bold;
}
</style>
<div class='title0'>我的課程</div>
<div class='inbox'>
	<div class='title'>課程: 基礎瑜珈</div>
	<div class='title'>>&nbsp;</div>
</div>
<div class='inbox'>
	<div class='title'>課程: 輔具瑜珈</div>
	<div class='title'>>&nbsp;</div>
</div>
<div class='inbox'>
	<div class='title'>課程: 哈達瑜珈</div>
	<div class='title'>>&nbsp;</div>
</div>
<div class='inbox'>
	<div class='title'>課程: 陰瑜珈</div>
	<div class='title'>>&nbsp;</div>
</div>
<div class='inbox'>
	<div class='title'>課程: 艾揚格瑜珈</div>
	<div class='title'>>&nbsp;</div>
</div>