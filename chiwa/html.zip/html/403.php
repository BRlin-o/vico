<?php

$domainName = $_SERVER['SERVER_NAME'];
header("Location: //$domainName/");